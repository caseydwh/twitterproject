package com.tts.ttstwitter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TtstwitterApplicationTests {

    @Test
    void contextLoads() {
    }

}
